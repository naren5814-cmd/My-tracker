import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart' as p;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest.dart' as tzdata;
import 'package:timezone/timezone.dart' as tz;
import 'package:intl/intl.dart';
import 'package:fl_chart/fl_chart.dart';

const indigo = Color(0xFF4F46E5);
const cyan = Color(0xFF06B6D4);
const subjectsDefault = [
  'Tamil', 'General Studies', 'Aptitude', 'Current Affairs',
  'Indian History', 'Indian Polity', 'Geography', 'Indian Economy',
  'General Science', 'Tamil Nadu History', 'Tamil Nadu Administration', 'Revision'
];

final db = StudyDb();
final notifications = FlutterLocalNotificationsPlugin();
const widgetChannel = MethodChannel('tnpsc_tracker/widget');

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  try {
    await db.init();
  } catch (e, st) {
    runApp(MaterialApp(home: Scaffold(body: SafeArea(child: Padding(
      padding: const EdgeInsets.all(16),
      child: SingleChildScrollView(child: Text('Startup error:\n$e\n\n$st')))))));
    return;
  }
  runApp(const TrackerApp());
  try { await NotificationService.init(); } catch (_) {}
  await refreshWidget();
}

Future<void> refreshWidget() async {
  try {
    final seconds = await todaySeconds();
    final targetMinutes = int.tryParse(await db.setting('daily_target_min', '300')) ?? 300;
    await widgetChannel.invokeMethod('refresh', {
      'todaySeconds': seconds,
      'targetSeconds': targetMinutes * 60,
    });
  } catch (_) {}
}

class StudyDb {
  Database? _db;
  Future<void> init() async {
    final base = await getDatabasesPath();
    _db = await openDatabase(p.join(base, 'tnpsc_tracker.db'), version: 1,
      onCreate: (d, v) async {
        await d.execute('''CREATE TABLE subjects(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT UNIQUE NOT NULL)''');
        await d.execute('''CREATE TABLE sessions(id INTEGER PRIMARY KEY AUTOINCREMENT, subject TEXT NOT NULL, topic TEXT, start_ms INTEGER NOT NULL, end_ms INTEGER, duration_sec INTEGER NOT NULL DEFAULT 0, notes TEXT)''');
        await d.execute('''CREATE TABLE schedules(id INTEGER PRIMARY KEY AUTOINCREMENT, subject TEXT NOT NULL, topic TEXT, start_time TEXT NOT NULL, end_time TEXT NOT NULL, weekdays TEXT NOT NULL, enabled INTEGER NOT NULL DEFAULT 1)''');
        await d.execute('''CREATE TABLE tests(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, subject TEXT NOT NULL, test_date TEXT NOT NULL, total REAL NOT NULL, obtained REAL NOT NULL, correct INTEGER, wrong INTEGER, skipped INTEGER, duration_min INTEGER, notes TEXT)''');
        await d.execute('''CREATE TABLE settings(key TEXT PRIMARY KEY, value TEXT NOT NULL)''');
        for (final s in subjectsDefault) {
          await d.insert('subjects', {'name': s}, conflictAlgorithm: ConflictAlgorithm.ignore);
        }
        await d.insert('settings', {'key':'daily_target_min','value':'300'});
        await d.insert('settings', {'key':'theme_mode','value':'system'});
      });
  }
  Database get raw => _db!;
  Future<List<Map<String,Object?>>> rows(String sql, [List<Object?>? args]) => raw.rawQuery(sql,args);
  Future<int> insert(String table, Map<String,Object?> values) => raw.insert(table, values);
  Future<int> update(String table, Map<String,Object?> values, String where, List<Object?> args) => raw.update(table, values, where:where, whereArgs:args);
  Future<int> delete(String table, String where, List<Object?> args) => raw.delete(table, where:where, whereArgs:args);
  Future<String> setting(String key, String fallback) async {
    final r = await rows('SELECT value FROM settings WHERE key=?',[key]);
    return r.isEmpty ? fallback : r.first['value'] as String;
  }
  Future<void> setSetting(String key,String value) async {
    await raw.insert('settings', {'key':key,'value':value}, conflictAlgorithm:ConflictAlgorithm.replace);
  }
}

class NotificationService {
  static Future<void> init() async {
    tzdata.initializeTimeZones();
    try {
      final offsetMs = DateTime.now().timeZoneOffset.inMilliseconds;
      tz.Location? loc;
      if (offsetMs == 19800000) {
        loc = tz.getLocation('Asia/Kolkata');
      } else {
        for (final l in tz.timeZoneDatabase.locations.values) {
          if (l.currentTimeZone.offset == offsetMs) { loc = l; break; }
        }
      }
      if (loc != null) tz.setLocalLocation(loc);
    } catch (_) {}
    const android = AndroidInitializationSettings('@mipmap/ic_launcher');
    await notifications.initialize(const InitializationSettings(android: android));
    final androidPlugin = notifications.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
    await androidPlugin?.requestNotificationsPermission();
    await scheduleWeekly();
  }
  static Future<void> scheduleWeekly() async {
    await notifications.cancel(9001);
    final now = tz.TZDateTime.now(tz.local);
    var next = tz.TZDateTime(tz.local, now.year, now.month, now.day, 22);
    while (next.weekday != DateTime.sunday || !next.isAfter(now)) {
      next = next.add(const Duration(days:1));
      if (next.hour != 22) next = tz.TZDateTime(tz.local,next.year,next.month,next.day,22);
    }
    await notifications.zonedSchedule(9001, 'Your weekly TNPSC progress is ready',
      'Open Study Tracker to review your weekly progress card.',
      next, const NotificationDetails(android: AndroidNotificationDetails(
        'weekly_report','Weekly progress report', channelDescription:'Weekly TNPSC study summary',
        importance: Importance.high, priority: Priority.high)),
      androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
      uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime,
      matchDateTimeComponents: DateTimeComponents.dayOfWeekAndTime);
  }
}

class TrackerApp extends StatefulWidget {
  const TrackerApp({super.key});
  @override State<TrackerApp> createState()=>_TrackerAppState();
}
class _TrackerAppState extends State<TrackerApp> {
  ThemeMode mode = ThemeMode.system;
  @override void initState(){super.initState(); _load();}
  Future<void> _load() async {
    final v=await db.setting('theme_mode','system');
    if(!mounted)return;
    setState(()=>mode=v=='dark'?ThemeMode.dark:v=='light'?ThemeMode.light:ThemeMode.system);
  }
  void setMode(ThemeMode m) async {
    setState(()=>mode=m);
    await db.setSetting('theme_mode',m==ThemeMode.dark?'dark':m==ThemeMode.light?'light':'system');
  }
  @override Widget build(BuildContext context)=>MaterialApp(
    debugShowCheckedModeBanner:false, title:'TNPSC Study Tracker', themeMode:mode,
    theme: ThemeData(colorScheme:ColorScheme.fromSeed(seedColor:indigo,brightness:Brightness.light),
      useMaterial3:true, scaffoldBackgroundColor:const Color(0xFFF8FAFC), cardTheme:const CardThemeData(elevation:0)),
    darkTheme: ThemeData(colorScheme:ColorScheme.fromSeed(seedColor:indigo,brightness:Brightness.dark),
      useMaterial3:true, cardTheme:const CardThemeData(elevation:0)),
    home: HomeShell(onTheme:setMode, currentMode:mode));
}

class HomeShell extends StatefulWidget {
  final void Function(ThemeMode) onTheme; final ThemeMode currentMode;
  const HomeShell({super.key,required this.onTheme,required this.currentMode});
  @override State<HomeShell> createState()=>_HomeShellState();
}
class _HomeShellState extends State<HomeShell>{
  int index=0;
  @override Widget build(BuildContext context){
    final pages=[Dashboard(onNavigate:(i)=>setState(()=>index=i),onTheme:widget.onTheme),const StudyPage(),const SchedulePage(),const TestsPage(),const AnalyticsPage()];
    return Scaffold(body:SafeArea(child:pages[index]),
      bottomNavigationBar:NavigationBar(selectedIndex:index,onDestinationSelected:(i)=>setState(()=>index=i),
        destinations:const [
          NavigationDestination(icon:Icon(Icons.home_outlined),label:'Home'),
          NavigationDestination(icon:Icon(Icons.timer_outlined),label:'Study'),
          NavigationDestination(icon:Icon(Icons.calendar_month_outlined),label:'Schedule'),
          NavigationDestination(icon:Icon(Icons.fact_check_outlined),label:'Tests'),
          NavigationDestination(icon:Icon(Icons.insights_outlined),label:'Analytics'),
        ]),
      floatingActionButton:index==0?FloatingActionButton.extended(onPressed:()=>setState(()=>index=1),
        icon:const Icon(Icons.play_arrow),label:const Text('Start study')):null);
  }
}

String todayKey()=>DateFormat('yyyy-MM-dd').format(DateTime.now());
String fmtDuration(int sec)=>'${sec~/3600}h ${((sec%3600)~/60)}m';
Future<int> todaySeconds() async {
  final start=DateTime(DateTime.now().year,DateTime.now().month,DateTime.now().day).millisecondsSinceEpoch;
  final end=start+const Duration(days:1).inMilliseconds;
  final r=await db.rows('SELECT COALESCE(SUM(duration_sec),0) n FROM sessions WHERE start_ms>=? AND start_ms<?',[start,end]);
  return (r.first['n'] as num).toInt();
}
Future<List<Map<String,Object?>>> subjects() async=>db.rows('SELECT name FROM subjects ORDER BY name');

class Dashboard extends StatefulWidget{
  final ValueChanged<int> onNavigate; final void Function(ThemeMode) onTheme;
  const Dashboard({super.key,required this.onNavigate,required this.onTheme});
  @override State<Dashboard> createState()=>_DashboardState();
}
class _DashboardState extends State<Dashboard>{
  int seconds=0,target=300; List<Map<String,Object?>> recent=[];
  @override void initState(){super.initState();load();}
  Future<void> load() async {
    seconds=await todaySeconds(); target=int.tryParse(await db.setting('daily_target_min','300'))??300;
    recent=await db.rows('SELECT * FROM sessions ORDER BY start_ms DESC LIMIT 5');
    if(mounted)setState((){});
  }
  @override Widget build(BuildContext context){
    final pct=(seconds/60/target).clamp(0.0,1.0);
    return RefreshIndicator(onRefresh:load,child:ListView(padding:const EdgeInsets.all(18),children:[
      Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[
        Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
          Text('TNPSC STUDY TRACKER',style:Theme.of(context).textTheme.labelMedium?.copyWith(color:indigo,letterSpacing:1.2)),
          const SizedBox(height:4),Text('Vanakkam, Machiii 👋',style:Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight:FontWeight.bold))
        ]),
        PopupMenuButton<String>(icon:const Icon(Icons.palette_outlined),onSelected:(v){
          widget.onTheme(v=='dark'?ThemeMode.dark:v=='light'?ThemeMode.light:ThemeMode.system);
        },itemBuilder:(_)=>const [PopupMenuItem(value:'light',child:Text('Light mode')),PopupMenuItem(value:'dark',child:Text('Dark mode')),PopupMenuItem(value:'system',child:Text('System default'))])
      ]),
      const SizedBox(height:18),
      Card(child:Padding(padding:const EdgeInsets.all(18),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        const Text("TODAY'S STUDY",style:TextStyle(fontWeight:FontWeight.w600)),
        const SizedBox(height:12),Row(crossAxisAlignment:CrossAxisAlignment.end,children:[
          Text(fmtDuration(seconds),style:Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight:FontWeight.bold)),
          const Spacer(),Text('${(pct*100).round()}% of ${target~/60}h ${target%60}m')
        ]),
        const SizedBox(height:12),ClipRRect(borderRadius:BorderRadius.circular(20),child:LinearProgressIndicator(value:pct,minHeight:10,color:indigo)),
        const SizedBox(height:14),FilledButton.icon(onPressed:()=>widget.onNavigate(1),icon:const Icon(Icons.play_arrow),label:const Text('Start a study session'))
      ]))),
      const SizedBox(height:14),
      Row(children:[
        Expanded(child:_metric('Sessions',recent.length.toString(),Icons.timer_outlined)),
        const SizedBox(width:10),Expanded(child:FutureBuilder<List<Map<String,Object?>>>(
          future:db.rows('SELECT COUNT(*) n FROM tests WHERE test_date=?',[todayKey()]),
          builder:(c,s)=>_metric("Today's tests",s.hasData?'${s.data!.first['n']}':'—',Icons.quiz_outlined)))
      ]),
      const SizedBox(height:20),Text('Recent sessions',style:Theme.of(context).textTheme.titleLarge),
      const SizedBox(height:8),
      if(recent.isEmpty) const Text('No sessions yet. Start your first study session!'),
      ...recent.map((r)=>ListTile(contentPadding:EdgeInsets.zero,leading:const CircleAvatar(child:Icon(Icons.menu_book_outlined)),
        title:Text('${r['subject']}'),subtitle:Text(r['topic']?.toString().isNotEmpty==true?'${r['topic']}':'Study session'),
        trailing:Text(fmtDuration((r['duration_sec'] as num).toInt())))),
      const SizedBox(height:12),OutlinedButton.icon(onPressed:()=>widget.onNavigate(4),icon:const Icon(Icons.insights),label:const Text('View analytics'))
    ]));
  }
}
Widget _metric(String label,String value,IconData icon)=>Card(child:Padding(padding:const EdgeInsets.all(14),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
  Icon(icon,color:indigo),const SizedBox(height:8),Text(value,style:const TextStyle(fontSize:22,fontWeight:FontWeight.bold)),Text(label,style:const TextStyle(color:Colors.grey))
])));

class StudyPage extends StatefulWidget{const StudyPage({super.key});@override State<StudyPage> createState()=>_StudyPageState();}
class _StudyPageState extends State<StudyPage>{
  String subject=subjectsDefault.first; final topic=TextEditingController(); final notes=TextEditingController();
  int? sessionId; DateTime? started; Timer? ticker; int elapsed=0; bool paused=false; DateTime? pauseAt;
  @override void dispose(){ticker?.cancel();topic.dispose();notes.dispose();super.dispose();}
  Future<void> start() async {
    started=DateTime.now(); elapsed=0; paused=false;
    sessionId=await db.insert('sessions',{'subject':subject,'topic':topic.text.trim(),'start_ms':started!.millisecondsSinceEpoch,'duration_sec':0,'notes':''});
    ticker=Timer.periodic(const Duration(seconds:1),(_){if(!paused&&mounted)setState(()=>elapsed=DateTime.now().difference(started!).inSeconds);});
    await refreshWidget(); setState((){});
  }
  Future<void> pauseResume() async {
    if(!paused){paused=true;pauseAt=DateTime.now();ticker?.cancel();}
    else {final gap=DateTime.now().difference(pauseAt!).inSeconds;started=started!.add(Duration(seconds:gap));paused=false;
      ticker=Timer.periodic(const Duration(seconds:1),(_){if(!paused&&mounted)setState(()=>elapsed=DateTime.now().difference(started!).inSeconds);});}
    setState((){});
  }
  Future<void> end() async {
    if(sessionId==null)return;
    ticker?.cancel();
    final end=DateTime.now();
    await db.update('sessions',{'end_ms':end.millisecondsSinceEpoch,'duration_sec':elapsed,'notes':notes.text.trim()},'id=?',[sessionId]);
    sessionId=null;started=null;elapsed=0;paused=false;
    await refreshWidget(); if(mounted)setState((){});
    if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Study session saved')));
  }
  @override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.all(18),children:[
    Text('Study session',style:Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight:FontWeight.bold)),
    const SizedBox(height:16),
    if(sessionId==null)...[
      FutureBuilder(future:subjects(),builder:(c,s)=>DropdownButtonFormField<String>(value:subject,decoration:const InputDecoration(labelText:'Subject',border:OutlineInputBorder()),items:(s.data??subjectsDefault.map((e)=>{'name':e}).toList()).map((r)=>DropdownMenuItem(value:r['name'] as String,child:Text(r['name'] as String))).toList(),onChanged:(v)=>setState(()=>subject=v??subject))),
      const SizedBox(height:12),TextField(controller:topic,decoration:const InputDecoration(labelText:'Topic (optional)',border:OutlineInputBorder())),
      const SizedBox(height:12),FilledButton.icon(onPressed:start,icon:const Icon(Icons.play_arrow),label:const Text('START STUDY'))
    ] else ...[
      Card(child:Padding(padding:const EdgeInsets.all(24),child:Column(children:[
        Text(subject,style:Theme.of(context).textTheme.titleLarge),
        const SizedBox(height:18),Text(fmtDuration(elapsed),style:Theme.of(context).textTheme.displayMedium?.copyWith(fontWeight:FontWeight.bold,color:indigo)),
        Text(paused?'PAUSED':'STUDYING',style:TextStyle(color:paused?Colors.orange:Colors.green,fontWeight:FontWeight.bold)),
        const SizedBox(height:20),Row(children:[
          Expanded(child:OutlinedButton.icon(onPressed:pauseResume,icon:Icon(paused?Icons.play_arrow:Icons.pause),label:Text(paused?'Resume':'Pause'))),
          const SizedBox(width:10),Expanded(child:FilledButton.icon(onPressed:end,icon:const Icon(Icons.stop),label:const Text('End & save')))
        ])
      ]))),
      const SizedBox(height:12),TextField(controller:notes,decoration:const InputDecoration(labelText:'Session notes',border:OutlineInputBorder()),maxLines:3)
    ],
    const SizedBox(height:20),const Text('Tip: Keep the app open during a session in this starter version. Android background recovery is listed in the next-step notes.')
  ]);
}

class SchedulePage extends StatefulWidget{const SchedulePage({super.key});@override State<SchedulePage> createState()=>_SchedulePageState();}
class _SchedulePageState extends State<SchedulePage>{
  Future<void> add() async {
    final sub=TextEditingController(text:subjectsDefault.first), topic=TextEditingController();
    final start=TextEditingController(text:'05:00'), end=TextEditingController(text:'07:00');
    final days=TextEditingController(text:'1,2,3,4,5,6');
    await showDialog(context:context,builder:(ctx)=>AlertDialog(title:const Text('Add study slot'),content:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,children:[
      TextField(controller:sub,decoration:const InputDecoration(labelText:'Subject')),
      TextField(controller:topic,decoration:const InputDecoration(labelText:'Topic')),
      TextField(controller:start,decoration:const InputDecoration(labelText:'Start time (HH:mm)')),
      TextField(controller:end,decoration:const InputDecoration(labelText:'End time (HH:mm)')),
      TextField(controller:days,decoration:const InputDecoration(labelText:'Weekdays (1=Mon ... 7=Sun)'))
    ])),actions:[TextButton(onPressed:()=>Navigator.pop(ctx),child:const Text('Cancel')),FilledButton(onPressed:()async{
      await db.insert('schedules',{'subject':sub.text.trim(),'topic':topic.text.trim(),'start_time':start.text.trim(),'end_time':end.text.trim(),'weekdays':days.text.trim(),'enabled':1});
      if(ctx.mounted)Navigator.pop(ctx); if(mounted)setState((){});
    },child:const Text('Save'))]));
  }
  @override Widget build(BuildContext context)=>ScaffoldLikePage(title:'My schedule',action:IconButton(onPressed:add,icon:const Icon(Icons.add)),child:FutureBuilder(future:db.rows('SELECT * FROM schedules ORDER BY start_time'),builder:(c,s){
    final list=s.data??[];
    if(list.isEmpty)return const Center(child:Text('No study slots yet. Tap + to create your timetable.'));
    return ListView(children:list.map((r)=>Card(child:ListTile(leading:const Icon(Icons.schedule,color:indigo),
      title:Text('${r['start_time']} – ${r['end_time']}  •  ${r['subject']}'),
      subtitle:Text('${r['topic']}  |  Days: ${r['weekdays']}'),
      trailing:IconButton(icon:const Icon(Icons.delete_outline),onPressed:()async{await db.delete('schedules','id=?',[r['id']]);setState((){});} )))).toList());
  }));
}

class TestsPage extends StatefulWidget{const TestsPage({super.key});@override State<TestsPage> createState()=>_TestsPageState();}
class _TestsPageState extends State<TestsPage>{
  Future<void> add() async {
    final name=TextEditingController(), subject=TextEditingController(text:'General Studies'), total=TextEditingController(text:'100'), obtained=TextEditingController(), correct=TextEditingController(), wrong=TextEditingController(), skipped=TextEditingController(), mins=TextEditingController();
    await showDialog(context:context,builder:(ctx)=>AlertDialog(title:const Text('Add test result'),content:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,children:[
      TextField(controller:name,decoration:const InputDecoration(labelText:'Test name')),
      TextField(controller:subject,decoration:const InputDecoration(labelText:'Subject')),
      TextField(controller:total,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Total marks')),
      TextField(controller:obtained,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Marks obtained')),
      TextField(controller:correct,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Correct answers')),
      TextField(controller:wrong,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Wrong answers')),
      TextField(controller:skipped,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Unanswered')),
      TextField(controller:mins,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Time taken (minutes)'))
    ])),actions:[TextButton(onPressed:()=>Navigator.pop(ctx),child:const Text('Cancel')),FilledButton(onPressed:()async{
      final t=double.tryParse(total.text)??0,o=double.tryParse(obtained.text)??0;
      if(name.text.trim().isEmpty||t<=0||o<0||o>t){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Enter valid test name and marks')));return;}
      await db.insert('tests',{'name':name.text.trim(),'subject':subject.text.trim(),'test_date':todayKey(),'total':t,'obtained':o,'correct':int.tryParse(correct.text),'wrong':int.tryParse(wrong.text),'skipped':int.tryParse(skipped.text),'duration_min':int.tryParse(mins.text)});
      if(ctx.mounted)Navigator.pop(ctx);if(mounted)setState((){});
    },child:const Text('Save'))]));
  }
  @override Widget build(BuildContext context)=>ScaffoldLikePage(title:'Test scores',action:IconButton(onPressed:add,icon:const Icon(Icons.add)),child:FutureBuilder(future:db.rows('SELECT * FROM tests ORDER BY test_date DESC,id DESC'),builder:(c,s){
    final list=s.data??[];
    if(list.isEmpty)return const Center(child:Text('No tests recorded. Tap + to add your first score.'));
    return ListView(children:list.map((r){final pct=(r['obtained'] as num)/(r['total'] as num)*100;return Card(child:ListTile(
      leading:CircleAvatar(child:Text('${pct.round()}%')),title:Text('${r['name']} • ${r['subject']}'),
      subtitle:Text('${r['test_date']}  |  ${r['obtained']}/${r['total']}'),
      trailing:IconButton(icon:const Icon(Icons.delete_outline),onPressed:()async{await db.delete('tests','id=?',[r['id']]);setState((){});})));}).toList());
  }));
}

class AnalyticsPage extends StatefulWidget{const AnalyticsPage({super.key});@override State<AnalyticsPage> createState()=>_AnalyticsPageState();}
class _AnalyticsPageState extends State<AnalyticsPage>{
  @override Widget build(BuildContext context)=>ScaffoldLikePage(title:'Analytics',child:FutureBuilder(future:loadAnalytics(),builder:(c,s){
    if(!s.hasData)return const Center(child:CircularProgressIndicator());
    final d=s.data!;final secs=d['seconds'] as int;final tests=d['tests'] as List<Map<String,Object?>>;
    final avg=tests.isEmpty?0:tests.map((r)=>(r['obtained'] as num)/(r['total'] as num)*100).reduce((a,b)=>a+b)/tests.length;
    final bySubject=d['bySubject'] as List<Map<String,Object?>>;
    return ListView(padding:const EdgeInsets.all(16),children:[
      Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        const Text('Total recorded study time'),const SizedBox(height:8),Text(fmtDuration(secs),style:Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight:FontWeight.bold))
      ]))),
      const SizedBox(height:10),Row(children:[Expanded(child:_metric('Tests',tests.length.toString(),Icons.quiz)),const SizedBox(width:10),Expanded(child:_metric('Average score','${avg.toStringAsFixed(1)}%',Icons.trending_up))]),
      const SizedBox(height:18),Text('Study time by subject',style:Theme.of(context).textTheme.titleLarge),
      const SizedBox(height:12),
      if(bySubject.isEmpty)const Text('Study sessions will appear here.'),
      ...bySubject.map((r){final v=(r['sec'] as num).toInt();return ListTile(title:Text('${r['subject']}'),subtitle:LinearProgressIndicator(value:(v/(secs==0?1:secs)).clamp(0.0,1.0),color:indigo),trailing:Text(fmtDuration(v)));}),
      const SizedBox(height:18),Text('Weekly study hours',style:Theme.of(context).textTheme.titleLarge),
      SizedBox(height:190,child:BarChart(BarChartData(
        borderData:FlBorderData(show:false),gridData:const FlGridData(show:true),
        titlesData:FlTitlesData(leftTitles:const AxisTitles(sideTitles:SideTitles(showTitles:true,reservedSize:34)),
          bottomTitles:AxisTitles(sideTitles:SideTitles(showTitles:true,getTitlesWidget:(v,m)=>Padding(padding:const EdgeInsets.only(top:6),child:Text(['M','T','W','T','F','S','S'][v.toInt().clamp(0,6)]))))),
        barGroups:(d['week'] as List<int>).asMap().entries.map((e)=>BarChartGroupData(x:e.key,barRods:[BarChartRodData(toY:e.value/3600,width:14,color:indigo,borderRadius:BorderRadius.circular(4))])).toList()
      ))),
      const SizedBox(height:20),FilledButton.icon(onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const Scaffold(body:SafeArea(child:WeeklyReportPage())))),icon:const Icon(Icons.assessment),label:const Text('View weekly progress card'))
    ]);
  }));
}
Future<Map<String,Object>> loadAnalytics() async {
  final total=await db.rows('SELECT COALESCE(SUM(duration_sec),0) n FROM sessions');
  final by=await db.rows('SELECT subject,SUM(duration_sec) sec FROM sessions GROUP BY subject ORDER BY sec DESC');
  final tests=await db.rows('SELECT * FROM tests ORDER BY test_date DESC');
  final now=DateTime.now();final monday=DateTime(now.year,now.month,now.day).subtract(Duration(days:now.weekday-1));
  final week=<int>[];
  for(int i=0;i<7;i++){final a=monday.add(Duration(days:i)).millisecondsSinceEpoch,b=monday.add(Duration(days:i+1)).millisecondsSinceEpoch;
    final r=await db.rows('SELECT COALESCE(SUM(duration_sec),0) n FROM sessions WHERE start_ms>=? AND start_ms<?',[a,b]);week.add((r.first['n'] as num).toInt());}
  return {'seconds':(total.first['n'] as num).toInt(),'bySubject':by,'tests':tests,'week':week};
}

class WeeklyReportPage extends StatelessWidget{
  const WeeklyReportPage({super.key});
  @override Widget build(BuildContext context)=>ScaffoldLikePage(title:'Weekly progress',child:FutureBuilder(future:weeklyData(),builder:(c,s){
    if(!s.hasData)return const Center(child:CircularProgressIndicator());
    final d=s.data!;final total=d['total'] as int;final tests=d['tests'] as List<Map<String,Object?>>;final by=d['by'] as List<Map<String,Object?>>;
    final avg=tests.isEmpty?0:tests.map((r)=>(r['obtained'] as num)/(r['total'] as num)*100).reduce((a,b)=>a+b)/tests.length;
    return ListView(padding:const EdgeInsets.all(16),children:[
      Card(child:Padding(padding:const EdgeInsets.all(20),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        const Text('MY WEEKLY REPORT',style:TextStyle(letterSpacing:1.4,fontWeight:FontWeight.bold,color:indigo)),
        const SizedBox(height:14),Text(fmtDuration(total),style:Theme.of(context).textTheme.displaySmall?.copyWith(fontWeight:FontWeight.bold)),
        const Text('Total study time this week'),
        const SizedBox(height:18),Row(children:[Expanded(child:_metric('Study sessions','${d['count']}',Icons.timer)),const SizedBox(width:8),Expanded(child:_metric('Tests','${tests.length}',Icons.quiz)),const SizedBox(width:8),Expanded(child:_metric('Average score','${avg.toStringAsFixed(1)}%',Icons.school))])
      ]))),
      const SizedBox(height:12),Text('Subject breakdown',style:Theme.of(context).textTheme.titleLarge),
      ...by.map((r)=>ListTile(title:Text('${r['subject']}'),trailing:Text(fmtDuration((r['sec'] as num).toInt())))),
      const SizedBox(height:10),const Text('Use this report to choose next week’s revision priorities. Your report uses only records saved on this phone.')
    ]);
  }));
}
Future<Map<String,dynamic>> weeklyData() async {
  final now=DateTime.now();final monday=DateTime(now.year,now.month,now.day).subtract(Duration(days:now.weekday-1));
  final a=monday.millisecondsSinceEpoch,b=monday.add(const Duration(days:7)).millisecondsSinceEpoch;
  final total=await db.rows('SELECT COALESCE(SUM(duration_sec),0) n FROM sessions WHERE start_ms>=? AND start_ms<?',[a,b]);
  final count=await db.rows('SELECT COUNT(*) n FROM sessions WHERE start_ms>=? AND start_ms<?',[a,b]);
  final by=await db.rows('SELECT subject,SUM(duration_sec) sec FROM sessions WHERE start_ms>=? AND start_ms<? GROUP BY subject ORDER BY sec DESC',[a,b]);
  final tests=await db.rows('SELECT * FROM tests WHERE test_date>=? AND test_date<?',[DateFormat('yyyy-MM-dd').format(monday),DateFormat('yyyy-MM-dd').format(monday.add(const Duration(days:7)))]);
  return {'total':(total.first['n'] as num).toInt(),'count':count.first['n'],'by':by,'tests':tests};
}

class ScaffoldLikePage extends StatelessWidget{
  final String title;final Widget child;final Widget? action;
  const ScaffoldLikePage({super.key,required this.title,required this.child,this.action});
  @override Widget build(BuildContext context)=>Column(children:[
    Padding(padding:const EdgeInsets.fromLTRB(18,14,12,10),child:Row(children:[Expanded(child:Text(title,style:Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight:FontWeight.bold))),if(action!=null)action!])),
    Expanded(child:child)
  ]);
}
