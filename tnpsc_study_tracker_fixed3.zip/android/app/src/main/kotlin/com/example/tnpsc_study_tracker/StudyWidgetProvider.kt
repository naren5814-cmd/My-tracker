package com.example.tnpsc_study_tracker

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

class StudyWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { update(context, manager, it) }
    }
    companion object {
        fun update(context: Context, manager: AppWidgetManager, id: Int) {
            val p = context.getSharedPreferences("tnpsc_widget", Context.MODE_PRIVATE)
            val sec = p.getInt("today_seconds", 0)
            val target = p.getInt("target_seconds", 18000).coerceAtLeast(1)
            val pct = ((sec.toFloat() / target) * 100).toInt().coerceIn(0, 100)
            val views = RemoteViews(context.packageName, R.layout.study_widget)
            views.setTextViewText(R.id.widget_title, "TNPSC STUDY")
            views.setTextViewText(R.id.widget_time, "${sec/3600}h ${(sec%3600)/60}m studied")
            views.setTextViewText(R.id.widget_progress, "$pct% of daily target")
            views.setProgressBar(R.id.widget_bar, 100, pct, false)
            val intent = context.packageManager.getLaunchIntentForPackage(context.packageName)
            val pending = PendingIntent.getActivity(context, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            views.setOnClickPendingIntent(R.id.widget_root, pending)
            manager.updateAppWidget(id, views)
        }
    }
}
