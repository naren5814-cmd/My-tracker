package com.example.tnpsc_study_tracker

import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity: FlutterActivity() {
    private val channel = "tnpsc_tracker/widget"
    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, channel).setMethodCallHandler { call, result ->
            if (call.method == "refresh") {
                val seconds = call.argument<Int>("todaySeconds") ?: 0
                val target = call.argument<Int>("targetSeconds") ?: 18000
                getSharedPreferences("tnpsc_widget", Context.MODE_PRIVATE).edit()
                    .putInt("today_seconds", seconds)
                    .putInt("target_seconds", target)
                    .apply()
                val manager = AppWidgetManager.getInstance(this)
                val ids = manager.getAppWidgetIds(ComponentName(this, StudyWidgetProvider::class.java))
                ids.forEach { StudyWidgetProvider.update(this, manager, it) }
                result.success(true)
            } else result.notImplemented()
        }
    }
}
