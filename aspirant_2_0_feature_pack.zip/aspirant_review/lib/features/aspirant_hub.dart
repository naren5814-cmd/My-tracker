import 'package:flutter/material.dart';
import 'package:sqflite/sqflite.dart';
import 'package:intl/intl.dart';

/// Extra competitive-exam tools. Uses the existing SQLite database.
class AspirantHub extends StatelessWidget {
  final Database database;
  const AspirantHub({super.key, required this.database});

  @override
  Widget build(BuildContext context) {
    final items = <_HubItem>[
      _HubItem('Syllabus tracker', 'Track every subject, unit and topic', Icons.checklist, () => _open(context, SyllabusPage(database: database))),
      _HubItem('Revision planner', 'Schedule 1, 3, 7, 15 and 30-day revisions', Icons.replay_circle_filled, () => _open(context, RevisionPage(database: database))),
      _HubItem('Mistake notebook', 'Save wrong answers and revisit weak areas', Icons.menu_book, () => _open(context, MistakesPage(database: database))),
      _HubItem('Current affairs vault', 'Save daily news notes with categories', Icons.newspaper, () => _open(context, NotesPage(database: database))),
      _HubItem('Exam countdown', 'Keep your target exam date visible', Icons.event, () => _open(context, ExamPage(database: database))),
    ];
    return ListView(padding: const EdgeInsets.all(18), children: [
      Text('Preparation tools', style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.bold)),
      const SizedBox(height: 6),
      const Text('Your preparation, organised in one place.'),
      const SizedBox(height: 18),
      ...items.map((item) => Card(child: ListTile(
        leading: CircleAvatar(child: Icon(item.icon)), title: Text(item.title, style: const TextStyle(fontWeight: FontWeight.w600)),
        subtitle: Text(item.subtitle), trailing: const Icon(Icons.chevron_right), onTap: item.onTap,
      ))),
    ]);
  }
  void _open(BuildContext context, Widget page) => Navigator.push(context, MaterialPageRoute(builder: (_) => page));
}

class _HubItem {
  final String title, subtitle; final IconData icon; final VoidCallback onTap;
  _HubItem(this.title, this.subtitle, this.icon, this.onTap);
}

/// Run once after the existing StudyDb.init(). CREATE IF NOT EXISTS is safe for old installs.
Future<void> initAspirantTables(Database db) async {
  await db.execute('''CREATE TABLE IF NOT EXISTS syllabus_topics(
    id INTEGER PRIMARY KEY AUTOINCREMENT, exam TEXT NOT NULL, subject TEXT NOT NULL,
    unit TEXT NOT NULL, topic TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'Not started',
    updated_at TEXT NOT NULL)''');
  await db.execute('''CREATE TABLE IF NOT EXISTS revision_items(
    id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, subject TEXT NOT NULL,
    due_date TEXT NOT NULL, completed INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL)''');
  await db.execute('''CREATE TABLE IF NOT EXISTS mistakes(
    id INTEGER PRIMARY KEY AUTOINCREMENT, question TEXT NOT NULL, subject TEXT NOT NULL,
    correct_answer TEXT, explanation TEXT, review_date TEXT NOT NULL, resolved INTEGER NOT NULL DEFAULT 0)''');
  await db.execute('''CREATE TABLE IF NOT EXISTS study_notes(
    id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, category TEXT NOT NULL,
    body TEXT NOT NULL, created_at TEXT NOT NULL)''');
  await db.execute('''CREATE TABLE IF NOT EXISTS exam_targets(
    id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, exam_date TEXT NOT NULL, is_primary INTEGER NOT NULL DEFAULT 0)''');
}

String _today() => DateFormat('yyyy-MM-dd').format(DateTime.now());

class SyllabusPage extends StatefulWidget {
  final Database database; const SyllabusPage({super.key, required this.database});
  @override State<SyllabusPage> createState() => _SyllabusPageState();
}
class _SyllabusPageState extends State<SyllabusPage> {
  String exam = 'TNPSC Group 2';
  Future<List<Map<String,Object?>>> _items() => widget.database.query('syllabus_topics', where: 'exam=?', whereArgs: [exam], orderBy: 'subject, unit, topic');
  Future<void> _add() async {
    final subject = TextEditingController(), unit = TextEditingController(), topic = TextEditingController();
    final ok = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(title: const Text('Add syllabus topic'), content: Column(mainAxisSize: MainAxisSize.min, children: [TextField(controller: subject, decoration: const InputDecoration(labelText: 'Subject')), TextField(controller: unit, decoration: const InputDecoration(labelText: 'Unit / chapter')), TextField(controller: topic, decoration: const InputDecoration(labelText: 'Topic'))]), actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')), FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Save'))]));
    if (ok == true && subject.text.trim().isNotEmpty && topic.text.trim().isNotEmpty) {
      await widget.database.insert('syllabus_topics', {'exam':exam,'subject':subject.text.trim(),'unit':unit.text.trim(),'topic':topic.text.trim(),'status':'Not started','updated_at':_today()});
      if (mounted) setState(() {});
    }
    subject.dispose(); unit.dispose(); topic.dispose();
  }
  Future<void> _status(Map<String,Object?> row, String status) async { await widget.database.update('syllabus_topics', {'status':status,'updated_at':_today()}, where:'id=?', whereArgs:[row['id']]); if(mounted)setState((){}); }
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Syllabus tracker'), actions:[PopupMenuButton<String>(initialValue:exam,onSelected:(v)=>setState(()=>exam=v),itemBuilder:(_)=>['TNPSC Group 1','TNPSC Group 2','TNPSC Group 2A','TNPSC Group 4','SSC CGL','Other'].map((e)=>PopupMenuItem(value:e,child:Text(e))).toList())]), floatingActionButton: FloatingActionButton.extended(onPressed:_add,icon:const Icon(Icons.add),label:const Text('Add topic')), body: FutureBuilder<List<Map<String,Object?>>>(future:_items(),builder:(context,s){final rows=s.data??[]; final done=rows.where((e)=>e['status']=='Completed').length; final pct=rows.isEmpty?0.0:done/rows.length; return ListView(padding:const EdgeInsets.all(16),children:[Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('$done / ${rows.length} topics completed',style:Theme.of(context).textTheme.titleMedium),const SizedBox(height:10),LinearProgressIndicator(value:pct),const SizedBox(height:6),Text('${(pct*100).round()}% syllabus completion')]))),if(rows.isEmpty) const Padding(padding:EdgeInsets.all(24),child:Text('No topics added yet. Add your first subject topic.')),...rows.map((r)=>Card(child:ListTile(title:Text('${r['topic']}'),subtitle:Text('${r['subject']} • ${r['unit']}'),trailing:DropdownButton<String>(value:r['status'] as String,items:const [DropdownMenuItem(value:'Not started',child:Text('Pending')),DropdownMenuItem(value:'Learning',child:Text('Learning')),DropdownMenuItem(value:'Revision',child:Text('Revision')),DropdownMenuItem(value:'Completed',child:Text('Done'))],onChanged:(v){if(v!=null)_status(r,v);}))))]);}));
}

class RevisionPage extends StatefulWidget { final Database database; const RevisionPage({super.key,required this.database}); @override State<RevisionPage> createState()=>_RevisionPageState(); }
class _RevisionPageState extends State<RevisionPage> {
  Future<List<Map<String,Object?>>> _load()=>widget.database.query('revision_items',orderBy:'completed ASC, due_date ASC');
  Future<void> _add() async { final title=TextEditingController(), subject=TextEditingController(); DateTime due=DateTime.now().add(const Duration(days:1)); final ok=await showDialog<bool>(context:context,builder:(ctx)=>StatefulBuilder(builder:(ctx,setD)=>AlertDialog(title:const Text('Schedule revision'),content:Column(mainAxisSize:MainAxisSize.min,children:[TextField(controller:title,decoration:const InputDecoration(labelText:'Topic')),TextField(controller:subject,decoration:const InputDecoration(labelText:'Subject')),TextButton.icon(onPressed:()async{final d=await showDatePicker(context:ctx,initialDate:due,firstDate:DateTime.now().subtract(const Duration(days:365)),lastDate:DateTime.now().add(const Duration(days:3650)));if(d!=null)setD(()=>due=d);},icon:const Icon(Icons.calendar_month),label:Text(DateFormat.yMMMd().format(due))) ]),actions:[TextButton(onPressed:()=>Navigator.pop(ctx,false),child:const Text('Cancel')),FilledButton(onPressed:()=>Navigator.pop(ctx,true),child:const Text('Save'))]))); if(ok==true&&title.text.trim().isNotEmpty){await widget.database.insert('revision_items',{'title':title.text.trim(),'subject':subject.text.trim().isEmpty?'General':subject.text.trim(),'due_date':DateFormat('yyyy-MM-dd').format(due),'completed':0,'created_at':_today()});if(mounted)setState((){});} title.dispose();subject.dispose(); }
  Future<void> _toggle(Map<String,Object?> r,bool done)async{await widget.database.update('revision_items',{'completed':done?1:0},where:'id=?',whereArgs:[r['id']]);if(mounted)setState((){});}
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('Revision planner')),floatingActionButton:FloatingActionButton.extended(onPressed:_add,icon:const Icon(Icons.add),label:const Text('Schedule')),body:FutureBuilder<List<Map<String,Object?>>>(future:_load(),builder:(c,s){final rows=s.data??[];return ListView(padding:const EdgeInsets.all(16),children:[const Text('Use spaced revision: revise after 1, 3, 7, 15 and 30 days.'),const SizedBox(height:12),if(rows.isEmpty)const Text('No revision tasks yet.'),...rows.map((r){final due=DateTime.tryParse(r['due_date'] as String)??DateTime.now();final overdue=due.isBefore(DateTime.now())&&(r['completed'] as int)==0;return Card(child:CheckboxListTile(value:(r['completed'] as int)==1,onChanged:(v)=>_toggle(r,v??false),title:Text(r['title'] as String),subtitle:Text('${r['subject']} • ${DateFormat.yMMMd().format(due)}${overdue?' • OVERDUE':''}')));})]);}));
}

class MistakesPage extends StatefulWidget { final Database database; const MistakesPage({super.key,required this.database}); @override State<MistakesPage> createState()=>_MistakesPageState(); }
class _MistakesPageState extends State<MistakesPage> {
  Future<List<Map<String,Object?>>> _load()=>widget.database.query('mistakes',orderBy:'resolved ASC, review_date ASC');
  Future<void> _add()async{final q=TextEditingController(),a=TextEditingController(),e=TextEditingController(),s=TextEditingController();final ok=await showDialog<bool>(context:context,builder:(ctx)=>AlertDialog(title:const Text('Record a mistake'),content:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,children:[TextField(controller:q,decoration:const InputDecoration(labelText:'Question / concept'),maxLines:2),TextField(controller:s,decoration:const InputDecoration(labelText:'Subject')),TextField(controller:a,decoration:const InputDecoration(labelText:'Correct answer')),TextField(controller:e,decoration:const InputDecoration(labelText:'Why was my answer wrong?'),maxLines:3)])),actions:[TextButton(onPressed:()=>Navigator.pop(ctx,false),child:const Text('Cancel')),FilledButton(onPressed:()=>Navigator.pop(ctx,true),child:const Text('Save'))]));if(ok==true&&q.text.trim().isNotEmpty){await widget.database.insert('mistakes',{'question':q.text.trim(),'subject':s.text.trim().isEmpty?'General':s.text.trim(),'correct_answer':a.text.trim(),'explanation':e.text.trim(),'review_date':_today(),'resolved':0});if(mounted)setState((){});}q.dispose();a.dispose();e.dispose();s.dispose();}
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('Mistake notebook')),floatingActionButton:FloatingActionButton.extended(onPressed:_add,icon:const Icon(Icons.add),label:const Text('Add mistake')),body:FutureBuilder<List<Map<String,Object?>>>(future:_load(),builder:(c,s){final rows=s.data??[];return ListView(padding:const EdgeInsets.all(16),children:[Text('${rows.where((r)=>(r['resolved'] as int)==0).length} concepts to revisit'),const SizedBox(height:10),if(rows.isEmpty)const Text('Record mistakes from your mock tests here.'),...rows.map((r)=>Card(child:ExpansionTile(title:Text(r['question'] as String),subtitle:Text('${r['subject']} • ${r['resolved']==1?'Reviewed':'Needs revision'}'),childrenPadding:const EdgeInsets.all(16),children:[if((r['correct_answer'] as String? ?? '').isNotEmpty)Text('Correct answer: ${r['correct_answer']}'),if((r['explanation'] as String? ?? '').isNotEmpty)Text('Learning note: ${r['explanation']}'),Align(alignment:Alignment.centerRight,child:TextButton(onPressed:()async{await widget.database.update('mistakes',{'resolved':(r['resolved'] as int)==1?0:1},where:'id=?',whereArgs:[r['id']]);if(mounted)setState((){});},child:Text((r['resolved'] as int)==1?'Mark pending':'Mark reviewed')))])))]);}));
}

class NotesPage extends StatefulWidget { final Database database; const NotesPage({super.key,required this.database}); @override State<NotesPage> createState()=>_NotesPageState(); }
class _NotesPageState extends State<NotesPage>{
  Future<List<Map<String,Object?>>> _load()=>widget.database.query('study_notes',orderBy:'created_at DESC');
  Future<void> _add()async{final title=TextEditingController(),body=TextEditingController();String category='Current Affairs';final ok=await showDialog<bool>(context:context,builder:(ctx)=>StatefulBuilder(builder:(ctx,setD)=>AlertDialog(title:const Text('Save a note'),content:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,children:[TextField(controller:title,decoration:const InputDecoration(labelText:'Title')),DropdownButtonFormField<String>(value:category,items:const ['Current Affairs','Polity','History','Geography','Economy','Science','Tamil','Aptitude','Other'].map((e)=>DropdownMenuItem(value:e,child:Text(e))).toList(),onChanged:(v)=>setD(()=>category=v??category)),TextField(controller:body,decoration:const InputDecoration(labelText:'Notes'),maxLines:5)])),actions:[TextButton(onPressed:()=>Navigator.pop(ctx,false),child:const Text('Cancel')),FilledButton(onPressed:()=>Navigator.pop(ctx,true),child:const Text('Save'))])));if(ok==true&&title.text.trim().isNotEmpty){await widget.database.insert('study_notes',{'title':title.text.trim(),'category':category,'body':body.text.trim(),'created_at':DateTime.now().toIso8601String()});if(mounted)setState((){});}title.dispose();body.dispose();}
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('Current affairs & notes')),floatingActionButton:FloatingActionButton.extended(onPressed:_add,icon:const Icon(Icons.add),label:const Text('New note')),body:FutureBuilder<List<Map<String,Object?>>>(future:_load(),builder:(c,s){final rows=s.data??[];return ListView(padding:const EdgeInsets.all(16),children:[if(rows.isEmpty)const Text('Save important current affairs and subject notes here.'),...rows.map((r)=>Card(child:ListTile(title:Text(r['title'] as String),subtitle:Text('${r['category']} • ${(r['body'] as String).replaceAll('\n',' ')}',maxLines:2,overflow:TextOverflow.ellipsis),onTap:()=>showDialog(context:context,builder:(ctx)=>AlertDialog(title:Text(r['title'] as String),content:SingleChildScrollView(child:Text(r['body'] as String)),actions:[TextButton(onPressed:()=>Navigator.pop(ctx),child:const Text('Close'))])))))]);}));
}

class ExamPage extends StatefulWidget { final Database database; const ExamPage({super.key,required this.database}); @override State<ExamPage> createState()=>_ExamPageState(); }
class _ExamPageState extends State<ExamPage>{
  Future<List<Map<String,Object?>>> _load()=>widget.database.query('exam_targets',orderBy:'is_primary DESC, exam_date ASC');
  Future<void> _add()async{final name=TextEditingController();DateTime date=DateTime.now().add(const Duration(days:60));final ok=await showDialog<bool>(context:context,builder:(ctx)=>StatefulBuilder(builder:(ctx,setD)=>AlertDialog(title:const Text('Add target exam'),content:Column(mainAxisSize:MainAxisSize.min,children:[TextField(controller:name,decoration:const InputDecoration(labelText:'Exam name')),TextButton.icon(onPressed:()async{final d=await showDatePicker(context:ctx,initialDate:date,firstDate:DateTime.now(),lastDate:DateTime.now().add(const Duration(days:3650)));if(d!=null)setD(()=>date=d);},icon:const Icon(Icons.calendar_month),label:Text(DateFormat.yMMMd().format(date)))]),actions:[TextButton(onPressed:()=>Navigator.pop(ctx,false),child:const Text('Cancel')),FilledButton(onPressed:()=>Navigator.pop(ctx,true),child:const Text('Save'))])));if(ok==true&&name.text.trim().isNotEmpty){await widget.database.insert('exam_targets',{'name':name.text.trim(),'exam_date':DateFormat('yyyy-MM-dd').format(date),'is_primary':0});if(mounted)setState((){});}name.dispose();}
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('Exam countdown')),floatingActionButton:FloatingActionButton.extended(onPressed:_add,icon:const Icon(Icons.add),label:const Text('Add exam')),body:FutureBuilder<List<Map<String,Object?>>>(future:_load(),builder:(c,s){final rows=s.data??[];return ListView(padding:const EdgeInsets.all(16),children:[if(rows.isEmpty)const Text('Add your target exam date to see the countdown.'),...rows.map((r){final date=DateTime.tryParse(r['exam_date'] as String)??DateTime.now();final days=date.difference(DateTime.now()).inDays;return Card(child:ListTile(leading:const CircleAvatar(child:Icon(Icons.flag)),title:Text(r['name'] as String),subtitle:Text(DateFormat.yMMMd().format(date)),trailing:Text(days<0?'Date passed':'$days days',style:const TextStyle(fontWeight:FontWeight.bold))));})]);}));
}
